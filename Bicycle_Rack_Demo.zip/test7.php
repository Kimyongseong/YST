<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$name = $_POST['name'];  
$address = $_POST['address'];  



$res = mysqli_query($con,"select * from login where email = '$name' and password = '$address';");  



$result = array(); 
   
    while($row = mysqli_fetch_array($res))
	{  
        
		array_push($result, array('email'=>$row[0],'password'=>$row[1]));  
        } 
   
     
$json = json_encode(array("result"=>$result));
echo $json;

mysqli_close($con);  
?>