<?php  

$con=mysqli_connect("localhost","root","tjdals12","server");  

mysqli_set_charset($con,"utf8");

if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  
$name = $_POST['name'];  
$address = $_POST['address'];  
$c = $_POST['c'];
  
$result = mysqli_query($con,"update server set da = '$address' , he = '$c' where dev = '$name';");  
  
  if($result){  
    echo 'success';  
  }  
  else{  
    echo 'failure';  
  }  
  
mysqli_close($con);  
?> 
 
