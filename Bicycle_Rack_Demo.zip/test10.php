<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$name = $_POST['name'];  




$res = mysqli_query($con,"update dev set status = '$name' where number = '1';");  




mysqli_close($con);  
?>