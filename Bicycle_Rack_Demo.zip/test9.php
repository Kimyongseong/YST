<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$name = $_POST['name'];  




$res = mysqli_query($con,"select * from dev where number = '$name';");  



$result = array(); 
   
    while($row = mysqli_fetch_array($res))
	{  
        
		array_push($result, array('number'=>$row[0],'ip'=>$row[1],'status'=>$row[2],'w'=>$row[3],'g'=>$row[4]));  
        } 
   
     
$json = json_encode(array("result"=>$result));
echo $json;

mysqli_close($con);  
?>