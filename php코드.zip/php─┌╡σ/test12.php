<?php  

$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$c = $_POST['c'];  
$login = $_POST['login']; 
$dev = $_POST['dev']; 

$res = mysqli_query($con,"update dev set $c=0   where number = '$dev' && $c = '$login';");  






mysqli_close($con);





  
?>

