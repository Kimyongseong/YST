<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$name = $_POST['name'];  

$res = mysqli_query($con,"select * from dev where number = '$name';");  



$result = array(); 
   
    while($row = mysqli_fetch_array($res))
	{  
        
		array_push($result, array('number'=>$row[0],'ip'=>$row[1],'w'=>$row[2],'g'=>$row[3],'st1'=>$row[4],'st2'=>$row[5],'st3'=>$row[6]));  
        } 
   
     
$json = json_encode(array("result"=>$result));
echo $json;

mysqli_close($con);  
?>