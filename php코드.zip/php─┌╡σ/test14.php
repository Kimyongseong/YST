<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$c = $_POST['c'];  
$login = $_POST['login']; 
$dev = $_POST['dev'];


$res = mysqli_query($con,"select * from w;");  



$result = array(); 
   
    while($row = mysqli_fetch_array($res))
	{  
        
		array_push($result, array('w1'=>$row[0],'g1'=>$row[1],'w2'=>$row[2],'g2'=>$row[3],'w3'=>$row[4],'g3'=>$row[5],'w4'=>$row[6],'g4'=>$row[7]));  
        } 
   
     
$json = json_encode(array("result"=>$result));
echo $json;

mysqli_close($con);  
?>