<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$c = $_POST['c'];  
$login = $_POST['login']; 
$dev = $_POST['dev'];


$res = mysqli_query($con,"select $c from dev  where number = '$dev';");  



$result = array(); 
   
    while($row = mysqli_fetch_array($res))
	{  
        
		array_push($result, array('p'=>$row[0]));  
        } 
   
     
$json = json_encode(array("result"=>$result));
echo $json;

mysqli_close($con);  
?>