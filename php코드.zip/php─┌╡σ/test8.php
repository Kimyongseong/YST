<?php  
$con=mysqli_connect("localhost","root","tjdals12","server");  
mysqli_set_charset($con,"utf8");
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}  

$name = $_POST['name'];  
$address = $_POST['address'];  



$res = mysqli_query($con,"select * from login where email = '$name' and password = '$address';");  



   
    $row = mysqli_fetch_array($res)
	  
    

   if($row){$json = json_encode("ok");}

     
   else{$json = json_encode("no");}
     

echo $json;

mysqli_close($con);  
?>